#ifndef _MOTOR_H_
#define _MOTOR_H_

#include "stm32f1xx_hal.h"
#include "tim.h"
#include "math.h"
#include "pid.h"

#define PI 3.14159265358979323846f
#define Motor_Pole_Pairs 7

typedef enum Motor_Mode_Type
{
    Motor_Mode_Stop,
    Motor_Mode_Angle,
    Motor_Mode_Speed
} Motor_Mode_Type;

extern Motor_Mode_Type Motor_Mode;
extern PID Motor_Angle;
extern PID Motor_Speed;

extern float Motor_PWM_Duty_a;
extern float Motor_PWM_Duty_b;
extern float Motor_PWM_Duty_c;

extern uint16_t rxData;
extern float Motor_Current_Angle;

extern float Motor_Voltage_Limit = 10;
extern float Motor_Power_Voltage = 12.6;
extern float Motor_Zero_Electric_Angle = 0;

void Motor_Init();

void Motor_TransmitReceive();

void Motor_Set_Angle_Goal_Deg(float angle);

void Motor_Set_Speed_Goal(float speed);

void Motor_TIM();
#endif